
from functions import remove_punctuation


def test_remove_punctuation():
"""Test for my function."""

    assert callable(remove_punctuation)
    assert remove_punctuation("I. love! to. punctuate!!!!") == "I love to punctuate
    assert remove_punctuation("H.o.w. d.o.e.s. .t.h.i.s. .h.a.p.p.e.n) == 'How does this happen"
    assert remove_punctuation(ab.c.@;d,e!!!..) == abcde
                           