"""A collection of functions for doing my project."""

import string

import random

import nltk

import os

import random

from IPython.display import Image, display


#Remove Punctuation function was used from assignment 3
def remove_punctuation(input_string):
    """Remove punctuation from an input string.
    
    Parameters
    ----------
    input_string : string
        The string containing punctuation.
    
    Returns
    -------
    out_string : string
        The string without punctuation.
    """
    
    out_string = ''
    for char in input_string:
        if char not in string.punctuation:
            out_string += char
            
    return out_string


#Prepare Text function was used from assignment 3
def prepare_text(input_string):
    """Apply multiple functions to an input string to prepare it to be processed.
    
    Parameters
    ----------
    input_string : string
        The string in its imput form which may be composed of multiple words, \ 
        contain uppercases, and punctuation.
        
    Returns
    -------
    out_list : list of strings
        The list of the imput words that are now lowercase and without punctuation.
    """
    temp_string = input_string.lower()
    temp_string = remove_punctuation(temp_string)
    out_list = temp_string.split()
    
    return out_list


#Selector function was used from assignment 3
def selector(input_list, check_list, return_list):
    """Takes a list of input words, a list of words to check if the input contains them, \ 
    and a list of possible outputs if input words appear on check list.
    
    Parameters
    ----------
    input_list : list of strings
        The list of prepared input words.
    check_list : list of strings 
        The list of words to check for if they appear in the input.
    output_list : list of strings
        The list of possible outcomes based on the check_list.
        
    Returns
    -------
    output : string or None
        A randomly chosen string from the output list based on the input and the check_list.
    """

    output = None
    for word in input_list:
        if word in check_list:
            output = random.choice(return_list)
            break

    return output


#String concatenator was used from assignment 3
def string_concatenator(string1, string2, separator):
    """Concatenates two strings by combining them with a separator.
    
    Parameters
    ----------
    string1 : string
        The first string to be concatenated.
    string2 : string
        The second string to be concatenated.
    separator : string
        The string to seperate the two concatenated strings. 
        
    Returns
    -------
    result : string or None
        The concatenated strings seperated by the separator.
    """
    
    result = string1 + separator + string2
    
    return result


#List to String was used from assignment 3
def list_to_string(input_list, separator):
    """Turns an input list into concatenated strings combined with a separator.
    
    Parameters
    ----------
    input_list : list of strings
        The input list to be concatenated.
    separator : string
        The string which combines the concatenated input strings.
        
    Returns
    -------
    output : string
        The string of concatenated input strings separated by the separator.
    """
    
    output = input_list[0]
    for item in input_list[1:]:
        output = string_concatenator(output, item, separator)
        
    return output


#End Chat was used from assignment 3
def end_chat(input_list):
    """Ends chat with chatbot if word 'quit' appears.
    
    Parameters
    ----------
    input_list : list of strings
        The list of input strings.
    
    Returns
    -------
    output : boolean
        Ends chat if its True that quit appears in input list, otherwise it returns False.
    """
    
    if 'quit' in input_list:
        output = True
    else:
        output = False
        
    return output


#Is in list was used from assignment 3
def is_in_list(list_one, list_two):
    """Check if any element of list_one is in list_two.
    
    Parameters
    ----------
    list_one : list of strings 
        A list that will be compared with list_two.
    list_two : list of strings
        A list that will be checked to see if elements of list_one are in it.
        
    Returns
    -------
    Boolean : True or False
        True if element of list_one is in list two, False if not
    """
    
    for element in list_one:
        if element in list_two:
            return True
    
    return False


#Below defines a collection of input and output things Stacy can say and respond to.
#Collection format and some greetings were taken from assignment 3.
greetings_in = ['hello', 'hi', 'hiya', 'hey', 'hola', 'bonjour', 'greetings']
greetings_out = ['Hello, my name is Stacy and I am here to help you find a place to eat \
                around San Diego. What kind of food are you in the mood for?']

burger_type_food_in = ['burger', 'burgers', 'hamburger', 'hamburgers', 'lunch', 'dinner']
burger_place_out = ['The Burger Lounge is a great burger place!', 
                   'In-n-out burger is an all time favorite!',
                   "Hodad's is a great burger place.", 
                   "Carl's Jr, Rally's, and Jack in the Box are fast options.",
                   'STACKED is a great burger place.', 
                   "Fudrucker's is a great burger place.", "Five Guys is a great burger place.",
                   'Corvette Diner has great burgers.', 
                   "BJ's has great burgers and a variety of other American foods."]

italian_type_food_in = ['pizza', 'italian', 'pasta', 'lunch', 'dinner']
italian_place_out = ['Buona Forchetta is an authentic Italian food place!',
                    'Piacere Mio is a great Italian food place!',
                    'Buon Apetito is a great Italian food place.', 
                    "Mimmo's Italian Village is a big Italian hit.",
                    "Filippi's Pizza Grotto has delicious pizza and pasta.", 
                    'Olive Garden is a great Italian food place.',
                    'La Bella Pizza Garden has great pizza and a variety of other picks.', 
                    "D'Lish Gourmet Pasta & Pizza is a must."]

mexican_type_food_in = ['mexican', 'asada', 'tacos', 'lunch', 'dinner']
mexican_place_out = ['Tacos el Gordo is a great taco place.', 
                    'Taco shops are easy to find and offer a variety of Mexican food.',
                    'Casa Don Diego serves authentic and delicious Mexican food.', 
                     'La Querencia is a great option!']

chinese_type_food_in = ['chinese', 'lunch', 'dinner']
chinese_place_out = ['Mandarin is a great Chinese food place!', 
                    'Golden House Restaurant is a great Chinese food place.',
                    'The Asian Bistro offers a large variety of Chinese food.', 
                    'Dumpling Inn and Shangai is a great Chinese food place! ']

korean_type_food_in = ['korean', 'lunch', 'dinner']
korean_place_out = ['Manna BBQ is a great Korean bbq place!', 'K.Cuisine is a great Korean food place!', 
                   'Convoy Tofu House is a great Korean food place.', 
                   'Prime Grill has great Korean bbq.']

japanese_type_food_in = ['ramen', 'sushi', 'japanese', 'lunch', 'dinner']
japanese_place_out = ['Nishiki Ramen has amazing ramen!', 'Izakaya Maza has a great Japanase Cuisine!',
                     'NOBU has great Japanese food.', 'Underbelly has great ramen.', 
                     'Tajima has amazing ramen.', 'Ikiru Sushi is a great Japanese food place.',
                     'Hinotez has great rice bowls.', 'Izakaya Naruto has great ramen.',
                     'Sushiya has great sushi.']

mediterranean_type_food_in = ['mediterranean', 'greek', 'gyro', 'gyros', 'pita', 'lunch', 'dinner']
mediterranean_place_out = ["Daphne's has great Mediterranean food!", 
                          'Doner Mediterranean Grill is a great choice.',
                          'Mangos Grill is a great Mediterranean food place.', 
                          'Zorbas has a great Mediterranean cuisine!', 
                          "Spiro's Greek Cafe has amazing gyro sandwhiches."]

breakfast_type_food_in = ['breakfast', 'pancakes']
breakfast_place_out = ["Denny's is a great breakfast place!", 'IHop serves great pancakes.', 
                      'Galley at the Marina has great breakfast options.', 
                      'The Cottage serves delicious breakfast.',
                      'Family House of pancakes is a great breakfast place.', 
                      'Breakfast Republic is a must.','Snooze has great breakfast food.',
                      'Hash House A Go Go is a great breakfast place.',
                      'Fig Tree Cafe is a great breakfast option!']

dessert_type_food_in = ['dessert', 'cream', 'sweet', 'gelato']
dessert_place_out = ["BJ's serves great pizookies!", 'Extraordinary Desserts is a great option.',
                    'Thrifty Ice Cream is a go to.', 'Babycakes serves great pastries!', 
                    'Cold Stone is a great ice cream place.', 'Up2you Cafe serves great desserts.',
                    'MNGO Cafe is a great dessert stop.', 'Gelato Vero Cafe makes great gelato.', 
                    'Chocolat has great desserts!', 'Papalecco has amazing gelato.']

unknown = ["I'm sorry I cannot assist you with that."]



#Have a chat function was partially used from assignment 3 and modified to implement Stacy's functioning
def stacy_bot():
    """Main function to run Stacy."""
    
    chat = True
    while chat:

        # Get a message from the user
        msg = input('INPUT :\t')
        out_msg = None
        
        # Prepare the input message
        msg = prepare_text(msg)

        # Check for an end msg 
        if end_chat(msg):
            out_msg = "Nice talking to you, I hope I was able to help. Bon Appetit!"
            chat = False

        # Check for a selection of topics that we have defined to respond to
        #   Here, we will check for a series of topics that we have designed to answer to
        if not out_msg:

            # Initialize to collect a list of possible outputs
            outs = []
            
            
            # Check if the input looks like a greeting, add a greeting output if so
            outs.append(selector(msg, greetings_in, greetings_out))
            
    
            #Check if the input looks like burger type food, add a burger place output if so
            outs.append(selector(msg, burger_type_food_in, burger_place_out))
            
            #To engage the user better, check if input is burger type, and display a burger picture
            #in the output.
            if is_in_list(msg, burger_type_food_in):
                outs.append(display(Image(filename="pictures/burger.jpg")))
                
            
            #Check if the input looks like italian type food, add an italian place output if so
            outs.append(selector(msg, italian_type_food_in, italian_place_out))
            
            #Check if input is italian type, and display an italian food picture
            #in the output.
            if is_in_list(msg, italian_type_food_in):
                outs.append(display(Image(filename="pictures/italian.jpg")))
                
            
            #Check if the input looks like mexican type food, add a mexican place output if so
            outs.append(selector(msg, mexican_type_food_in, mexican_place_out))
            
            #Check if input is mexican type, and display a mexican food picture
            #in the output.
            if is_in_list(msg, mexican_type_food_in):
                outs.append(display(Image(filename="pictures/mexican.jpg")))
                
            
            #Check if the input looks like chinese type food, add a chinese place output if so
            outs.append(selector(msg, chinese_type_food_in, chinese_place_out))
            
            #Check if input is chinese type, and display a chinese food picture
            #in the output.
            if is_in_list(msg, chinese_type_food_in):
                outs.append(display(Image(filename="pictures/chinese.jpg")))
            
            
            #Check if the input looks like korean type food, add a korean place output if so
            outs.append(selector(msg, korean_type_food_in, korean_place_out))
            
            #Check if input is korean type, and display a korean food picture
            #in the output.
            if is_in_list(msg, korean_type_food_in):
                outs.append(display(Image(filename="pictures/korean.jpg")))
            
            
            #Check if the input looks like japanese type food, add a japanese place output if so
            outs.append(selector(msg, japanese_type_food_in, japanese_place_out))
            
            #Check if input is japanese type, and display a japanese food picture
            #in the output.
            if is_in_list(msg, japanese_type_food_in):
                outs.append(display(Image(filename="pictures/japanese.jpg")))
                
            
            #Check if the input looks like mediterranean type food, add a mediterranean place output if 
            #so
            outs.append(selector(msg, mediterranean_type_food_in, mediterranean_place_out))
            
            #Check if input is mediterranean type, and display a mediterranean food picture
            #in the output.
            if is_in_list(msg, mediterranean_type_food_in):
                outs.append(display(Image(filename="pictures/mediterranean.jpg")))
                
            
            #Check if the input looks like breakfast type food, add a breakfast place output if so
            outs.append(selector(msg, breakfast_type_food_in, breakfast_place_out))
            
            #Check if input is breakfast type, and display a breakfast food picture
            #in the output.
            if is_in_list(msg, breakfast_type_food_in):
                outs.append(display(Image(filename="pictures/breakfast.jpg")))
            
            
            #Check if the input looks like dessert type food, add a dessert place output if so
            outs.append(selector(msg, dessert_type_food_in, dessert_place_out))
            
            #Check if input is dessert type, and display a dessert picture
            #in the output.
            if is_in_list(msg, dessert_type_food_in):
                outs.append(display(Image(filename="pictures/dessert.jpg")))
                
            
            # We could have selected multiple outputs from the topic search above (if multiple return 
            #possible outputs)
            #   We also might have appended None in some cases, meaning we don't have a reply
            #   To deal with this, we are going to randomly select an output from the set of outputs 
            #that are not None
            options = list(filter(None, outs))
            if options:
                out_msg = random.choice(options)
                

        # Catch-all to say something if msg not caught & processed so far
        if not out_msg:
            out_msg = unknown[0]

        print('OUTPUT:', out_msg)

